package com.example.demo7;

import org.springframework.stereotype.Component;

@Component
public class Operand {
	double value = 30;
	public Operand() { }
	public double getValue() { return value; }
	public void setValue(double v) { value = v; }
}

    