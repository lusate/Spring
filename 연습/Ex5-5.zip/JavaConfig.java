package com.example.demo7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages = {"com.example.demo7"})
public class JavaConfig {
	@Bean
	public OperatorBean operatorBean() { //singleton
		OperatorBean plusOp = new PlusOp();
		//plusOp.setOperand1(operand());
		//plusOp.setOperand2(operand()); @Autowired 로 이거 뺌
		
		return plusOp;
	}
	
	//import appCtx5.xml
}
