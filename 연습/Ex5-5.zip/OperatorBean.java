package com.example.demo7;

import com.example.demo7.Operand;

public interface OperatorBean {
	double calc();
	Operand getOperand1();
	void setOperand1(Operand op);
	Operand getOperand2();
	void setOperand2(Operand op);
}

   //인터페이스 맞춰줌
