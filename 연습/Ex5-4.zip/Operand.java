package com.example.demo6;

public class Operand {
	double value;
	public Operand(double v) { value = v; }
	public double getValue() { return value; }
	public void setValue(double v) { value = v; }
}

    