package com.example.demo6;

import com.example.demo6.Operand;

public interface OperatorBean {
	double calc();
	Operand getOperand1();
	void setOperand1(Operand op);
	Operand getOperand2();
	void setOperand2(Operand op);
}

   //인터페이스 맞춰줌
