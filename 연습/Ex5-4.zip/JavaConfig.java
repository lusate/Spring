package com.example.demo6;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Scope;

@Configuration
@ImportResource("classpath:appCtx5.xml")
public class JavaConfig {
	@Bean
	public OperatorBean operatorBean() { //singleton
		OperatorBean plusOp = new PlusOp();
		//plusOp.setOperand1(operand());
		//plusOp.setOperand2(operand()); @Autowired 로 이거 뺌
		
		return plusOp;
	}
	
	//import appCtx5.xml
}
