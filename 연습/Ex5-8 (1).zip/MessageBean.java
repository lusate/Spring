package com.example.demo9;

public interface MessageBean {
	void sayHello(String name);
}
