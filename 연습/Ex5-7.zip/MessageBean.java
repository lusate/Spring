package com.example.demo8;

public interface MessageBean {
	void sayHello(String name);
}
