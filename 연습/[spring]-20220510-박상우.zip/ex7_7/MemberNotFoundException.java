package ex7_7;

public class MemberNotFoundException extends RuntimeException{

}
