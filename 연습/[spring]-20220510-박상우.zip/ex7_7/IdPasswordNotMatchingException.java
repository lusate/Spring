package ex7_7;

public class IdPasswordNotMatchingException extends RuntimeException{
	
}

