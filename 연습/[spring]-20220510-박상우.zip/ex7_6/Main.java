package ex7_6;

import java.time.LocalDateTime;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class Main {
	private static MemberDao memberDao;
	public static void main(String[] args) {
	AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCtx7_6.xml");
	memberDao = ctx.getBean("memberDao", MemberDao.class);
	// 새 멤버 추가 테스트, 실행할 때마다 email 값을 변경하여야 함
	Member member = new Member("guest1@gmail.com", "aaa", "Mr.Lee", LocalDateTime.now()); 
	memberDao.insert(member);
	System.out.println(member.getId());
	}
}
