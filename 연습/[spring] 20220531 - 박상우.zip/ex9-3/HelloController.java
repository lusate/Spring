package com.springmvc.pos;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {
	//@RequestMapping(value="/hello", method=RequestMethod.GET)
	@GetMapping("/hello")
	public String Hello(Model model, @RequestParam(value = "name", required = false) String name) {
		model.addAttribute("greeting", "안녕하세요, " + name);
		return "hello";
	}
	

	
	@GetMapping("/login")
	public String login(Model model) {
		return "login";
	}
	
	@GetMapping("/login_Check")
	public String login_Check(Model model, @RequestParam(value = "id") String id, @RequestParam(value = "pwd") String pwd) {
		if("abcd".equals(id) && "1234".equals(pwd)) {
			model.addAttribute("id", id);
		}
		
		return "login_Check";
	}
}
